CREATE FUNCTION addn(eno in number,ss out number) RETURN NUMBER
  --存储函数的参数不需要
is
  BEGIN
    select sex into ss  from text where id=eno;
    return ss;

  END;
/
