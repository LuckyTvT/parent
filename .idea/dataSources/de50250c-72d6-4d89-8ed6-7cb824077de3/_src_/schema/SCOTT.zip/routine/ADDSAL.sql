CREATE procedure addSal(eno in number)
  IS
    tt text%ROWTYPE;
  BEGIN
    select * into tt from text where id=eno;
    update text set sex = sex +2 where id = eno;

  END;
/
