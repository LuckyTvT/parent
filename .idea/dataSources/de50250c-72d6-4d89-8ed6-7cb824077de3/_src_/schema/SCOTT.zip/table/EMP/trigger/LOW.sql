CREATE TRIGGER LOW
BEFORE UPDATE
  ON EMP
FOR EACH ROW
  declare

  begin
    --if修改后工资 < 修改之前工资
    if :new.sal < :old.sal then
      dbms_output.put_line(111111);
    end if;
  end;
/
